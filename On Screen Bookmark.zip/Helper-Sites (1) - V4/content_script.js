


function overlayIcons() {
  // Get the current tab's URL
  const currentUrl = new URL(window.location.href);
  const domain = currentUrl.hostname;

  // Get bookmarks from chrome extension storage api
  chrome.storage.sync.get('bookmarks', (data) => {
    console.log('Bookmarks:', data.bookmarks);

    // Check if there is a match for the domain in the bookmarks data
    if (data.bookmarks && data.bookmarks[domain]) {
      console.log('Match found for', domain);

      // Create the icon container
      const box = document.createElement('div');
      box.id = 'twitter-box';

      // Create the icon elements from the bookmarks data
      const icons = document.createElement('div');
      icons.id = 'twitter-icons';

      const bookmarkData = data.bookmarks[domain];
      const bookmarkUrls = Object.values(bookmarkData).filter(url => url !== '');
      const numIcons = Math.min(bookmarkUrls.length, 5);

      for (let i = 0; i < numIcons; i++) {
        const icon = document.createElement('a');
        icon.classList.add('twitter-icon');
        icon.href = `http://${bookmarkUrls[i]}`;
        icon.target = '_blank';
        
        // Fetch the favicon of the bookmarked URL
        const faviconUrl = `https://www.google.com/s2/favicons?sz=32&domain=${bookmarkUrls[i]}`;
        icon.style.backgroundImage = `url('${faviconUrl}')`;
        
        icons.appendChild(icon);
      }

      // Add the icons to the container
      box.appendChild(icons);

      // Add the container to the page
      document.body.appendChild(box);
    } else {
      console.log('No match found for', domain);

      // Show the element with 5 icons
      
    }
  });

  console.log('Current URL:', currentUrl.toString());
}

overlayIcons();

window.addEventListener('load', () => {
  const twitterIconsDiv = document.getElementById('twitter-box');

  if (twitterIconsDiv) {
    twitterIconsDiv.addEventListener('mouseover', () => {
      twitterIconsDiv.style.opacity = '1';
    });

    twitterIconsDiv.addEventListener('mouseout', () => {
      twitterIconsDiv.style.opacity = '0';
    });
  }
});

