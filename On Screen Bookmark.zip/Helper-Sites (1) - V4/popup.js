function updateIcons() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var url = tabs[0].url;
    chrome.storage.sync.get('bookmarks', function(data) {
      var bookmarks = data['bookmarks'];
      var keys = Object.keys(bookmarks);
      for (var i = 0; i < keys.length; i++) {
        if (url.startsWith(keys[i])) {
          var bookmarksForUrl = bookmarks[keys[i]];
          var bookmarkKeys = Object.keys(bookmarksForUrl);
          for (var j = 1; j <= bookmarkKeys.length; j++) {
            var bookmark = bookmarksForUrl['Bookmark ' + j];
            if (bookmark !== '') {
              var icon = document.getElementById('icon' + j);
              icon.href = 'http://' + bookmark;
            }
          }
          break;
        }
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', function() {
  updateIcons();
});