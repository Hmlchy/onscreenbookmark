// select the download button
const downloadBtn = document.querySelector('#download-btn');

// add a click event listener to the download button
downloadBtn.addEventListener('click', () => {
  // get the data from the textarea
  const csvData = document.querySelector('#csv-input').value;
  
  // create a new Blob object with the data
  const blob = new Blob([csvData], {type: 'text/csv'});
  
  // create a temporary link element
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'data.csv';
  
  // simulate a click on the link to download the file
  link.click();
});

