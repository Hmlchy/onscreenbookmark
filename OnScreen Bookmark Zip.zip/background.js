

  chrome.runtime.onInstalled.addListener(function() {
    chrome.storage.sync.set({ 'bookmarks': {} }, function() {
      console.log('Empty JSON data stored in Chrome extension storage');
    });
  });
  