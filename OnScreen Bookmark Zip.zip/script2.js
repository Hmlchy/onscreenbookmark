document.addEventListener('DOMContentLoaded', function() {
  var convertBtn = document.getElementById('convert-btn');
  var jsonDataEl = document.getElementById('json-data');
  chrome.storage.sync.get('bookmarkscsv', function(result) {
    var csvData = result.bookmarkscsv;
    if (csvData) {
      document.getElementById('csv-input').value = csvData;
    }
  });
  convertBtn.addEventListener('click', function() {
    var csvInput = document.getElementById('csv-input').value;
    var jsonOutput = convertCsvToJson(csvInput);
    chrome.storage.sync.set({ 'bookmarks': jsonOutput, 'bookmarkscsv': csvInput }, function() {
      console.log('JSON data and raw CSV data stored in Chrome extension storage');
      jsonDataEl.textContent = JSON.stringify(jsonOutput, null, 2);
    });
  });

  chrome.storage.sync.get('bookmarks', function(result) {
    var jsonData = result.bookmarks;
    if (Object.keys(jsonData).length !== 0) {
      jsonDataEl.textContent = JSON.stringify(jsonData, null, 2);
    }
  });
});

function convertCsvToJson(csv) {
  var lines = csv.trim().split('\n');
  var headers = lines.shift().split(',');
  var jsonData = {};
  lines.forEach(function(line) {
    var values = line.split(',');
    var website = values[0];
    var bookmarks = {};
    for (var i = 1; i < values.length; i++) {
      bookmarks[headers[i]] = values[i];
    }
    jsonData[website] = bookmarks;
  });
  return jsonData;
}





